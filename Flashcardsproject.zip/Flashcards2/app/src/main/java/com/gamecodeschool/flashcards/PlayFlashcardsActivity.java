package com.gamecodeschool.flashcards;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class PlayFlashcardsActivity extends AppCompatActivity {
    private TextView questionTextView, answerTextView;
    private Button nextButton;
    private List<Flashcard> flashcards;
    private int currentFlashcardIndex;
    private boolean showingQuestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_flashcards);

        questionTextView = findViewById(R.id.questionTextView);
        answerTextView = findViewById(R.id.answerTextView);
        nextButton = findViewById(R.id.nextButton);

        flashcards = getFlashcardsFromDatabase();

        if (flashcards.isEmpty()) {
            Toast.makeText(this, "No flashcards found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentFlashcardIndex = 0;
        showingQuestion = true;

        showFlashcardQuestion();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (showingQuestion) {
                    showFlashcardAnswer();
                    nextButton.setText("Next");
                    showingQuestion = false;
                } else {
                    currentFlashcardIndex++;
                    showingQuestion = true;

                    if (currentFlashcardIndex >= flashcards.size()) {
                        Toast.makeText(PlayFlashcardsActivity.this, "No more flashcards", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        showFlashcardQuestion();
                        nextButton.setText("Show Answer");
                    }
                }
            }
        });
    }

    private void showFlashcardQuestion() {
        Flashcard currentFlashcard = flashcards.get(currentFlashcardIndex);
        questionTextView.setText(currentFlashcard.getQuestion());
        answerTextView.setVisibility(View.INVISIBLE);
    }

    private void showFlashcardAnswer() {
        Flashcard currentFlashcard = flashcards.get(currentFlashcardIndex);
        answerTextView.setText(currentFlashcard.getAnswer());
        answerTextView.setVisibility(View.VISIBLE);
    }

    private List<Flashcard> getFlashcardsFromDatabase() {
        FlashcardDatabaseHelper dbHelper = new FlashcardDatabaseHelper(this);
        return dbHelper.getAllFlashcards();
    }
}
