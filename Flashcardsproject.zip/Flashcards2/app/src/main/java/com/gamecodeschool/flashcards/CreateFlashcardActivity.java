package com.gamecodeschool.flashcards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateFlashcardActivity extends AppCompatActivity {
    private EditText questionEditText, answerEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_flashcard);

        questionEditText = findViewById(R.id.questionEditText);
        answerEditText = findViewById(R.id.answerEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String question = questionEditText.getText().toString().trim();
                String answer = answerEditText.getText().toString().trim();

                if (question.isEmpty() || answer.isEmpty()) {
                    Toast.makeText(CreateFlashcardActivity.this, "Please enter both question and answer", Toast.LENGTH_SHORT).show();
                } else {
                    // Create a new Flashcard object with a placeholder id (-1)
                    Flashcard flashcard = new Flashcard(-1, question, answer);

                    // Save the flashcard to the database
                    saveFlashcardToDatabase(flashcard);

                    Toast.makeText(CreateFlashcardActivity.this, "Flashcard saved successfully", Toast.LENGTH_SHORT).show();

                    // Clear the input fields
                    questionEditText.setText("");
                    answerEditText.setText("");
                }
            }
        });
    }

    private void saveFlashcardToDatabase(Flashcard flashcard) {
        FlashcardDatabaseHelper dbHelper = new FlashcardDatabaseHelper(this);
        dbHelper.addFlashcard(flashcard);
    }
}
