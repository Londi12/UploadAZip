package com.gamecodeschool.flashcards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FlashcardDetailsActivity extends AppCompatActivity {
    private TextView questionTextView, answerTextView;
    private Button editButton, deleteButton;
    private Flashcard flashcard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcard_details);

        questionTextView = findViewById(R.id.questionTextView);
        answerTextView = findViewById(R.id.answerTextView);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("flashcard")) {
            flashcard = (Flashcard) intent.getSerializableExtra("flashcard");
            if (flashcard != null) {
                displayFlashcardDetails();
            }
        }

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editIntent = new Intent(FlashcardDetailsActivity.this, EditFlashcardActivity.class);
                editIntent.putExtra("flashcard", flashcard);
                startActivity(editIntent);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFlashcard();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshFlashcardDetails();
    }

    private void displayFlashcardDetails() {
        questionTextView.setText(flashcard.getQuestion());
        answerTextView.setText(flashcard.getAnswer());
    }

    private void refreshFlashcardDetails() {
        FlashcardDatabaseHelper dbHelper = new FlashcardDatabaseHelper(this);
        flashcard = dbHelper.getFlashcardById(flashcard.getId());
        displayFlashcardDetails();
    }

    private void deleteFlashcard() {
        FlashcardDatabaseHelper dbHelper = new FlashcardDatabaseHelper(this);
        dbHelper.deleteFlashcard(flashcard);

        Toast.makeText(this, "Flashcard deleted", Toast.LENGTH_SHORT).show();

        finish();
    }
}
