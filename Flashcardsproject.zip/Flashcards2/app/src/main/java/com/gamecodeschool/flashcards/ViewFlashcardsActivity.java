package com.gamecodeschool.flashcards;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ViewFlashcardsActivity extends AppCompatActivity {
    private ListView flashcardsListView;
    private List<Flashcard> flashcards;
    private ArrayAdapter<Flashcard> flashcardsAdapter;
    private FlashcardDatabaseHelper dbHelper;
    private int selectedFlashcardIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_flashcards);

        flashcardsListView = findViewById(R.id.flashcardsListView);
        registerForContextMenu(flashcardsListView);

        dbHelper = new FlashcardDatabaseHelper(this);

        flashcards = dbHelper.getAllFlashcards();
        flashcardsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, flashcards);
        flashcardsListView.setAdapter(flashcardsAdapter);

        flashcardsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Flashcard selectedFlashcard = flashcards.get(position);

                Intent intent = new Intent(ViewFlashcardsActivity.this, FlashcardDetailsActivity.class);
                intent.putExtra("flashcard", selectedFlashcard);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.flashcard_context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        selectedFlashcardIndex = info.position;

        switch (item.getItemId()) {
            case R.id.editFlashcard:
                editFlashcard();
                return true;
            case R.id.deleteFlashcard:
                deleteFlashcard();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void editFlashcard() {
        Flashcard selectedFlashcard = flashcards.get(selectedFlashcardIndex);

        Intent intent = new Intent(ViewFlashcardsActivity.this, EditFlashcardActivity.class);
        intent.putExtra("flashcard", selectedFlashcard);
        startActivity(intent);
    }

    private void deleteFlashcard() {
        Flashcard selectedFlashcard = flashcards.get(selectedFlashcardIndex);
        flashcards.remove(selectedFlashcard);
        flashcardsAdapter.notifyDataSetChanged();

        dbHelper.deleteFlashcard(selectedFlashcard);

        Toast.makeText(this, "Flashcard deleted", Toast.LENGTH_SHORT).show();
    }
}

