package com.gamecodeschool.flashcards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditFlashcardActivity extends AppCompatActivity {
    private EditText questionEditText, answerEditText;
    private Button saveButton;

    private Flashcard flashcard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_flashcard);

        questionEditText = findViewById(R.id.questionEditText);
        answerEditText = findViewById(R.id.answerEditText);
        saveButton = findViewById(R.id.saveButton);

        Intent intent = getIntent();
        if (intent.hasExtra("flashcard")) {
            flashcard = (Flashcard) intent.getSerializableExtra("flashcard");
            if (flashcard != null) {
                questionEditText.setText(flashcard.getQuestion());
                answerEditText.setText(flashcard.getAnswer());
            }
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String question = questionEditText.getText().toString().trim();
                String answer = answerEditText.getText().toString().trim();

                if (question.isEmpty() || answer.isEmpty()) {
                    Toast.makeText(EditFlashcardActivity.this, "Please enter both question and answer", Toast.LENGTH_SHORT).show();
                } else {
                    if (flashcard != null) {
                        flashcard.setQuestion(question);
                        flashcard.setAnswer(answer);

                        // Update the flashcard in the database
                        updateFlashcardInDatabase(flashcard);

                        Toast.makeText(EditFlashcardActivity.this, "Flashcard updated successfully", Toast.LENGTH_SHORT).show();

                        // Finish the activity and return to the previous screen
                        finish();
                    }
                }
            }
        });
    }

    private void updateFlashcardInDatabase(Flashcard flashcard) {
        FlashcardDatabaseHelper dbHelper = new FlashcardDatabaseHelper(this);
        dbHelper.updateFlashcard(flashcard);
    }
}
